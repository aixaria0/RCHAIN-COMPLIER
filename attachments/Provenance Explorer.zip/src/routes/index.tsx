import { createFileRoute } from "@tanstack/react-router";
import { ClaimHeader } from "@/components/wb/ClaimHeader";
import { PipelineSpine } from "@/components/wb/PipelineSpine";
import { MobileNav } from "@/components/wb/Shell";
import {
  AdversarialControls,
  ComputationPanel,
  FailureWitnessPanel,
  InputsPanel,
  InvariantsPanel,
  MutationDetail,
  VerificationMatrix,
} from "@/components/wb/panels";
import { EvidenceRelationGraph } from "@/components/wb/graphs";
import { Panel, StatusTag, FieldRow } from "@/components/wb/primitives";
import { useWorkbench } from "@/lib/workbench-state";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Verification Workbench — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Trace a synthetic claim through inputs, computation, invariants, adversarial tests and evidence to a verification result tied to its evidence basis.",
      },
      { property: "og:title", content: "Verification Workbench — RChain Reality Compiler" },
      {
        property: "og:description",
        content:
          "Evidence-first verification workbench over a deterministic synthetic fixture. Not live chain evidence.",
      },
    ],
  }),
  component: Workbench,
});

function ResultPanel() {
  const { derived } = useWorkbench();
  return (
    <Panel
      title="Verification Result"
      subtitle="Result stated together with the evidence basis it rests on"
      right={<StatusTag status={derived.status} />}
    >
      <FieldRow label="verification result" value={derived.status} source="VerificationReport" field="status" />
      <FieldRow
        label="invariants satisfied"
        value={`${derived.invariants.filter((i) => i.status === "PASS").length} / ${derived.invariants.length}`}
        source="VerificationReport"
        field="invariants"
      />
      <FieldRow
        label="checks passed"
        value={`${derived.checks.filter((c) => c.status === "PASS").length} / ${derived.checks.length}`}
        source="VerificationReport"
        field="checks"
      />
      <FieldRow
        label="evidence records"
        value={String(derived.checks.reduce((n, c) => n + c.evidence.length, 0))}
        source="VerificationEvidence"
        field="count"
      />
      <FieldRow
        label="cross-node agreement"
        value={derived.computation.agreementRatio.toFixed(2)}
        source="CrossNodeReport"
        field="agreement_ratio"
      />
      <p className="mt-2 text-[11px] text-muted-foreground">
        This is a verification result over observed evidence from a synthetic fixture. It is
        not a proof, and it makes no statement about Casper finality or consensus.
      </p>
    </Panel>
  );
}

function StagePanel() {
  const { stage } = useWorkbench();
  switch (stage) {
    case "inputs":
      return <InputsPanel />;
    case "computation":
      return <ComputationPanel />;
    case "invariants":
      return <InvariantsPanel />;
    case "adversarial":
      return (
        <div className="grid gap-3">
          <AdversarialControls compact />
          <MutationDetail />
        </div>
      );
    case "evidence":
      return <EvidenceRelationGraph />;
    case "result":
      return <ResultPanel />;
    case "claim":
    default:
      return (
        <div className="grid gap-3 xl:grid-cols-2">
          <ComputationPanel />
          <InvariantsPanel />
        </div>
      );
  }
}

function Workbench() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <ClaimHeader />
      <Panel
        title="Verification Pipeline"
        subtitle="Select a stage to inspect its evidence without leaving the workbench"
      >
        <PipelineSpine />
      </Panel>
      <StagePanel />
      <FailureWitnessPanel />
      <VerificationMatrix />
    </div>
  );
}
