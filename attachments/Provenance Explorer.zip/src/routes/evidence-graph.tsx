import { createFileRoute } from "@tanstack/react-router";
import { MobileNav } from "@/components/wb/Shell";
import { EvidenceRelationGraph } from "@/components/wb/graphs";
import { VerificationMatrix } from "@/components/wb/panels";

export const Route = createFileRoute("/evidence-graph")({
  head: () => ({
    meta: [
      { title: "Evidence Graph — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Evidence relationships — observes, corroborates, compares, supports, produces — linking observations to the verification result.",
      },
      { property: "og:title", content: "Evidence Graph — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Every verdict traceable back to the observed evidence that supports it.",
      },
    ],
  }),
  component: EvidenceGraphView,
});

function EvidenceGraphView() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <EvidenceRelationGraph />
      <VerificationMatrix />
    </div>
  );
}
