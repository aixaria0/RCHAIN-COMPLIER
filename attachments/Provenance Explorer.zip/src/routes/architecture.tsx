import { createFileRoute } from "@tanstack/react-router";
import { MobileNav } from "@/components/wb/Shell";
import { Hint, Mono, Panel, SyntheticTag } from "@/components/wb/primitives";

export const Route = createFileRoute("/architecture")({
  head: () => ({
    meta: [
      { title: "Architecture — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Evidence pipeline from RNode through the evidence adapter, Sentinel observation and verification engine to the Reality Compiler and Causality Explorer.",
      },
      { property: "og:title", content: "Architecture — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Live components and planned adapter boundaries, stated separately.",
      },
    ],
  }),
  component: Architecture,
});

const PIPELINE = [
  { name: "RChain / RNode", note: "protocol source of block and validator state" },
  { name: "RChain Evidence Adapter", note: "reads protocol-shaped evidence" },
  { name: "EvidenceEnvelope", note: "carries source, field, value and provenance" },
  { name: "Sentinel Observation", note: "records what was observed, and what was not" },
  { name: "Verification Engine", note: "runs consistency checks over observations" },
  { name: "Evidence Graph", note: "relates evidence to each check" },
  { name: "Reality Compiler", note: "assembles claim, computation and result" },
  { name: "Causality Explorer", note: "presents the provenance spine" },
];

const PLANNED = [
  {
    name: "Rholang Execution Adapter",
    note: "would supply execution traces for deployed processes",
  },
  {
    name: "Sovereign-Lattice Verification Adapter",
    note: "separate PBFT protocol — never treated as RChain Casper",
  },
];

function Architecture() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <Panel
        title="Architecture"
        subtitle="Evidence path through the system"
        right={<SyntheticTag />}
      >
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_20rem]">
          <div>
            {PIPELINE.map((p, i) => (
              <div key={p.name}>
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 border border-border bg-panel/70 px-2.5 py-2">
                  <span className="text-[12.5px]">{p.name}</span>
                  <span className="text-[10.5px] text-muted-foreground">{p.note}</span>
                </div>
                {i < PIPELINE.length - 1 ? (
                  <svg className="h-5 w-6" viewBox="0 0 24 20" aria-hidden>
                    <line
                      x1="8"
                      y1="0"
                      x2="8"
                      y2="20"
                      className="flow-line"
                      stroke="var(--border-strong)"
                      strokeWidth="1"
                    />
                  </svg>
                ) : null}
              </div>
            ))}
          </div>

          <div className="border border-dashed border-accent/50 bg-accent/5 p-2">
            <h3 className="font-mono text-[10px] tracking-widest text-accent">
              ADAPTER BOUNDARY / PLANNED INTEGRATION
            </h3>
            <p className="mt-1 text-[10.5px] text-muted-foreground">
              Not live in this prototype. No undocumented API is assumed and no live endpoint
              is contacted.
            </p>
            <div className="mt-2 grid gap-2">
              {PLANNED.map((p) => (
                <div key={p.name} className="border border-border/70 bg-background/40 p-2">
                  <div className="text-[12px]">{p.name}</div>
                  <p className="mt-0.5 text-[10.5px] text-muted-foreground">{p.note}</p>
                  <Mono className="mt-1 block text-muted-foreground">status: PLANNED</Mono>
                </div>
              ))}
            </div>
          </div>
        </div>

        <p className="mt-3 text-[10.5px] text-muted-foreground">
          Principle:{" "}
          <Hint text="A claim is only shown alongside the evidence records that support it, and unavailable evidence is displayed as UNAVAILABLE rather than substituted.">
            evidence before claims
          </Hint>
          . Verification results state their evidence basis; nothing here asserts Casper
          finality or consensus.
        </p>
      </Panel>
    </div>
  );
}
