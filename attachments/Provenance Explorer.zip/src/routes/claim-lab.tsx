import { createFileRoute } from "@tanstack/react-router";
import { ClaimHeader } from "@/components/wb/ClaimHeader";
import { MobileNav } from "@/components/wb/Shell";
import { InputsPanel, InvariantsPanel } from "@/components/wb/panels";
import { Mono, Panel, StatusTag, SyntheticTag } from "@/components/wb/primitives";
import { useWorkbench } from "@/lib/workbench-state";

export const Route = createFileRoute("/claim-lab")({
  head: () => ({
    meta: [
      { title: "Claim Lab — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Decompose a claim into the invariants and consistency checks that support it, each tied to its evidence basis.",
      },
      { property: "og:title", content: "Claim Lab — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Claim decomposition into invariants, checks and evidence basis over a synthetic fixture.",
      },
    ],
  }),
  component: ClaimLab,
});

function Decomposition() {
  const { derived } = useWorkbench();
  return (
    <Panel
      title="Claim Decomposition"
      subtitle="What the claim requires, and which evidence path answers each requirement"
      right={<SyntheticTag />}
    >
      <div className="grid gap-2 lg:grid-cols-2">
        {derived.invariants.map((inv) => {
          const related = derived.checks.filter((c) =>
            inv.evidence.some((e) => e.source === c.source),
          );
          return (
            <div key={inv.id} className="border border-border/70 bg-background/40 p-2">
              <div className="flex items-center gap-2">
                <Mono className="text-accent">{inv.id}</Mono>
                <span className="text-[12px]">{inv.name}</span>
                <span className="ml-auto">
                  <StatusTag status={inv.status} />
                </span>
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">{inv.detail}</p>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {related.length ? (
                  related.map((c) => (
                    <span
                      key={c.id}
                      className="border border-border px-1.5 py-0.5 font-mono text-[9.5px] tracking-widest text-muted-foreground"
                    >
                      {c.id}
                    </span>
                  ))
                ) : (
                  <span className="font-mono text-[9.5px] tracking-widest text-muted-foreground">
                    FIXTURE CLASSIFICATION ONLY
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

function ClaimLab() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <ClaimHeader />
      <Decomposition />
      <InvariantsPanel />
      <InputsPanel />
    </div>
  );
}
