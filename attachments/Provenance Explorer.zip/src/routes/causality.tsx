import { createFileRoute } from "@tanstack/react-router";
import { MobileNav } from "@/components/wb/Shell";
import { CausalityGraph } from "@/components/wb/graphs";
import { FailureWitnessPanel } from "@/components/wb/panels";

export const Route = createFileRoute("/causality")({
  head: () => ({
    meta: [
      { title: "Causality Explorer — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Interactive provenance spine from source event through Rholang process, execution trace, block, observation and evidence to independent verification.",
      },
      { property: "og:title", content: "Causality Explorer — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Provenance preserved across every transformation of a synthetic fixture.",
      },
    ],
  }),
  component: Causality,
});

function Causality() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <CausalityGraph />
      <FailureWitnessPanel />
    </div>
  );
}
