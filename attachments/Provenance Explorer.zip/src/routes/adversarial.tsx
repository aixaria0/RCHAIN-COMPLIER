import { createFileRoute } from "@tanstack/react-router";
import { MobileNav } from "@/components/wb/Shell";
import {
  AdversarialControls,
  FailureWitnessPanel,
  InvariantsPanel,
  MutationDetail,
  VerificationMatrix,
} from "@/components/wb/panels";

export const Route = createFileRoute("/adversarial")({
  head: () => ({
    meta: [
      { title: "Adversarial Cases — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Apply deterministic mutations to a synthetic evidence baseline and watch the divergence propagate to invariants, checks and the verification result.",
      },
      { property: "og:title", content: "Adversarial Cases — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Deterministic adversarial mutations with a synthetic failure witness.",
      },
    ],
  }),
  component: Adversarial,
});

function Adversarial() {
  return (
    <div className="grid gap-3">
      <MobileNav />
      <AdversarialControls />
      <div className="grid gap-3 xl:grid-cols-2">
        <MutationDetail />
        <FailureWitnessPanel />
      </div>
      <InvariantsPanel />
      <VerificationMatrix />
    </div>
  );
}
