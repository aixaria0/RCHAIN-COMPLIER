import { createFileRoute } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { CASES, divergence } from "@/lib/fixture";
import { useWorkbench } from "@/lib/workbench-state";
import { MobileNav } from "@/components/wb/Shell";
import {
  AdversarialControls,
  FailureWitnessPanel,
} from "@/components/wb/panels";
import {
  FieldRow,
  Mono,
  Panel,
  StatusTag,
  SyntheticTag,
  Unavailable,
} from "@/components/wb/primitives";

export const Route = createFileRoute("/replay")({
  head: () => ({
    meta: [
      { title: "Replay / Divergence — RChain Reality Compiler" },
      {
        name: "description",
        content:
          "Replay the baseline and adversarial fixtures side by side and locate the first point where the two executions diverge.",
      },
      { property: "og:title", content: "Replay / Divergence — RChain Reality Compiler" },
      {
        property: "og:description",
        content: "Side-by-side replay isolating the first divergence between two deterministic runs.",
      },
    ],
  }),
  component: Replay,
});

function Replay() {
  const { derived, activeCase, isBaseline } = useWorkbench();
  const d = divergence(derived);
  const activeLabel = CASES.find((c) => c.id === activeCase);

  return (
    <div className="grid gap-3">
      <MobileNav />
      <Panel
        title="Replay / Divergence"
        subtitle="Same pipeline, two deterministic fixtures"
        right={<SyntheticTag />}
      >
        <div className="grid gap-3 lg:grid-cols-2">
          <div className="border border-border/70 bg-background/40 p-2">
            <div className="mb-1.5 flex items-center justify-between">
              <span className="font-mono text-[10px] tracking-widest text-muted-foreground">
                BASELINE FIXTURE
              </span>
              <StatusTag status={d.baseline.status} />
            </div>
            <FieldRow label="height" value={String(d.baseline.computation.commonHeight)} />
            <FieldRow
              label="hash"
              value={`${d.baseline.computation.commonHash?.slice(0, 6)}...${d.baseline.computation.commonHash?.slice(-4)}`}
            />
            <FieldRow
              label="agreement ratio"
              value={d.baseline.computation.agreementRatio.toFixed(2)}
            />
            <FieldRow label="status" value={d.baseline.status} />
          </div>
          <div
            className={cn(
              "border p-2",
              isBaseline ? "border-border/70 bg-background/40" : "border-warn/40 bg-warn/5",
            )}
          >
            <div className="mb-1.5 flex items-center justify-between">
              <span className="font-mono text-[10px] tracking-widest text-warn">
                {isBaseline
                  ? "ADVERSARIAL FIXTURE — NONE ACTIVE"
                  : `ADVERSARIAL FIXTURE — CASE ${activeCase}`}
              </span>
              <StatusTag status={derived.status} />
            </div>
            <FieldRow label="height" value={String(derived.computation.commonHeight)} />
            <FieldRow
              label="hash"
              value={`${derived.computation.commonHash?.slice(0, 6)}...${derived.computation.commonHash?.slice(-4)}`}
            />
            <FieldRow
              label="agreement ratio"
              value={derived.computation.agreementRatio.toFixed(2)}
            />
            <FieldRow label="status" value={derived.status} />
            {activeLabel ? (
              <p className="mt-1 text-[10.5px] text-warn">{activeLabel.mutationLine}</p>
            ) : null}
          </div>
        </div>

        <h3 className="mt-3 mb-1 font-mono text-[10px] tracking-widest text-primary">
          STEPWISE COMPARISON
        </h3>
        <div className="overflow-x-auto border border-border/70">
          <table className="w-full border-collapse text-left font-mono text-[10.5px]">
            <thead className="bg-muted/30 text-muted-foreground">
              <tr>
                <th className="px-2 py-1 font-normal tracking-widest">FIELD</th>
                <th className="px-2 py-1 font-normal tracking-widest">BASELINE</th>
                <th className="px-2 py-1 font-normal tracking-widest">ADVERSARIAL</th>
              </tr>
            </thead>
            <tbody>
              {d.rows.map((r) => (
                <tr
                  key={r.field}
                  className={cn(
                    "border-t border-border/50",
                    r.diverged && "bg-fail/5 text-fail",
                  )}
                >
                  <td className="px-2 py-1">{r.field}</td>
                  <td className="px-2 py-1">{r.baseline}</td>
                  <td className="px-2 py-1">{r.active}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <div className="grid gap-3 xl:grid-cols-2">
        <Panel title="Divergence Summary" subtitle="Where the two executions separate">
          {d.first ? (
            <div>
              <FieldRow label="First divergence" value={d.first.field} />
              <FieldRow label="Baseline value" value={d.first.baseline} />
              <FieldRow label="Adversarial value" value={d.first.active} />
              <FieldRow label="Affected invariant" value={d.affectedInvariant ?? "—"} />
              <FieldRow label="Affected verification check" value={d.affectedCheck ?? "—"} />
              <FieldRow label="Final result" value={derived.status} />
            </div>
          ) : (
            <Unavailable reason="Baseline and active fixtures are identical — no divergence to replay." />
          )}
          <p className="mt-2 text-[10.5px] text-muted-foreground">
            Both runs are deterministic replays of labelled synthetic fixtures.{" "}
            <Mono className="text-accent">no live chain data</Mono>
          </p>
        </Panel>
        <FailureWitnessPanel />
      </div>

      <AdversarialControls compact />
    </div>
  );
}
