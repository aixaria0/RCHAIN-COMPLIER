import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import { CASES, derive, type CaseId, type Derived } from "./fixture";

export type StageId =
  | "claim"
  | "inputs"
  | "computation"
  | "invariants"
  | "adversarial"
  | "evidence"
  | "result";

interface WorkbenchValue {
  activeCase: CaseId;
  setActiveCase: (id: CaseId) => void;
  runNextAdversarial: () => void;
  reset: () => void;
  stage: StageId;
  setStage: (s: StageId) => void;
  selectedNode: string;
  setSelectedNode: (id: string) => void;
  derived: Derived;
  isBaseline: boolean;
}

const WorkbenchContext = createContext<WorkbenchValue | null>(null);

export function WorkbenchProvider({ children }: { children: ReactNode }) {
  const [activeCase, setActiveCase] = useState<CaseId>("BASELINE");
  const [stage, setStage] = useState<StageId>("claim");
  const [selectedNode, setSelectedNode] = useState("event");

  const derived = useMemo(() => derive(activeCase), [activeCase]);

  const value: WorkbenchValue = {
    activeCase,
    setActiveCase,
    runNextAdversarial: () => {
      const idx = CASES.findIndex((c) => c.id === activeCase);
      setActiveCase(CASES[(idx + 1) % CASES.length]!.id);
    },
    reset: () => setActiveCase("BASELINE"),
    stage,
    setStage,
    selectedNode,
    setSelectedNode,
    derived,
    isBaseline: activeCase === "BASELINE",
  };

  return <WorkbenchContext.Provider value={value}>{children}</WorkbenchContext.Provider>;
}

export function useWorkbench() {
  const ctx = useContext(WorkbenchContext);
  if (!ctx) throw new Error("useWorkbench must be used inside WorkbenchProvider");
  return ctx;
}
