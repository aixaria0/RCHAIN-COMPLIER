/**
 * Deterministic synthetic fixture for the RChain Reality Compiler prototype.
 * Nothing here is live chain data. Every value is fabricated for UI /
 * architecture demonstration.
 */

export const SYNTHETIC_NOTICE =
  "SYNTHETIC FIXTURE — UI/architecture demonstration; not live chain evidence.";

export type Status = "PASS" | "WARN" | "FAIL" | "UNAVAILABLE";
export type Severity = "INFO" | "WARNING" | "CRITICAL";

export interface EvidenceRef {
  source: string;
  field: string;
  value: string;
}

export interface NodeObservation {
  node_id: string;
  network_id: string;
  shard_id: string;
  reachable: boolean;
  http_status: number | null;
  latency_ms: number | null;
  probe_integrity: boolean;
  ready: boolean;
  validator_state: string;
  current_epoch: number;
  last_finalized_block_number: number;
  latest_block_number: number;
  block_hash: string;
  parent_hash: string;
  proposer: string;
  signature_present: boolean;
  justification_present: boolean;
  justification_count: number;
  malformed_justification: boolean;
  duplicate_validator: boolean;
  payload_sha256: string;
  full_block_available: boolean;
  canonical_consistent: boolean;
  observed_stake: number;
  bond_count: number;
  peer_count: number;
}

export interface Fixture {
  claim: string;
  target: string;
  network: string;
  shard: string;
  block_height: number;
  block_hash: string;
  block_hash_short: string;
  observations: NodeObservation[];
}

export const FULL_HASH =
  "0x7f4a9c31b8e0d5a24f6719cbe0d3a8f5c1b27de49a06f3b8c5d1e7a2049b91c2";
export const SHORT_HASH = "0x7f4a...91c2";
const PARENT_HASH =
  "0x1c08b5d2f7a349e6108bd7c4a5230f9e1db64c78ff02a91e3c5d78b40a6e2f11";
const PAYLOAD_SHA =
  "sha256:9b1d3f0c7a26e548d1b0c93af52704e6ab8815d3c07f9e6421ba5f0d3c8e7712";

function observation(id: string, letter: string): NodeObservation {
  return {
    node_id: `synthetic-node-${letter}`,
    network_id: "synthetic-testnet",
    shard_id: "root",
    reachable: true,
    http_status: 200,
    latency_ms: 41 + letter.charCodeAt(0) - 65,
    probe_integrity: true,
    ready: true,
    validator_state: "bonded",
    current_epoch: 913,
    last_finalized_block_number: 184273,
    latest_block_number: 184276,
    block_hash: FULL_HASH,
    parent_hash: PARENT_HASH,
    proposer: `val_${id}`,
    signature_present: true,
    justification_present: true,
    justification_count: 4,
    malformed_justification: false,
    duplicate_validator: false,
    payload_sha256: PAYLOAD_SHA,
    full_block_available: true,
    canonical_consistent: true,
    observed_stake: 250_000,
    bond_count: 4,
    peer_count: 3,
  };
}

export const BASELINE: Fixture = {
  claim:
    "Observed finalized block is consistent across the available evidence paths.",
  target: "synthetic-rchain-node",
  network: "synthetic-testnet",
  shard: "root",
  block_height: 184273,
  block_hash: FULL_HASH,
  block_hash_short: SHORT_HASH,
  observations: [
    observation("0a17", "A"),
    observation("0b42", "B"),
    observation("0c88", "C"),
    observation("0d05", "D"),
  ],
};

/* ---------------------------------------------------------------- mutations */

export type CaseId = "BASELINE" | "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H";

export interface AdversarialCase {
  id: CaseId;
  label: string;
  summary: string;
  baselineLine: string;
  mutationLine: string;
  invariant: string;
  check: string;
}

export const CASES: AdversarialCase[] = [
  {
    id: "A",
    label: "Finalized height mismatch",
    summary: "One node reports a finalized height ahead of the others.",
    baselineLine: "node A/B/C/D = height 184273",
    mutationLine: "node C = height 184274",
    invariant: "I-01",
    check: "finalized_block_cross_check",
  },
  {
    id: "B",
    label: "Block hash mismatch",
    summary: "One node reports a different block hash at the same height.",
    baselineLine: "node A/B/C/D = 0x7f4a...91c2",
    mutationLine: "node D = 0x3e91...44ab",
    invariant: "I-02",
    check: "finalized_block_state",
  },
  {
    id: "C",
    label: "Missing block evidence",
    summary: "Full block payload is not retrievable from one node.",
    baselineLine: "full_block_available = true (4/4)",
    mutationLine: "node B full_block_available = false",
    invariant: "I-03",
    check: "finalized_block_state",
  },
  {
    id: "D",
    label: "Conflicting node observation",
    summary: "One node becomes unreachable mid-observation window.",
    baselineLine: "reachable = true (4/4)",
    mutationLine: "node D reachable = false, http_status = UNAVAILABLE",
    invariant: "I-04",
    check: "reachability",
  },
  {
    id: "E",
    label: "Missing justification",
    summary: "Justification set absent from one observation.",
    baselineLine: "justification_present = true (4/4)",
    mutationLine: "node A justification_present = false, count = 0",
    invariant: "I-06",
    check: "observation_integrity",
  },
  {
    id: "F",
    label: "Duplicate validator",
    summary: "Two observations advertise the same proposer identity.",
    baselineLine: "proposer identities distinct (4/4)",
    mutationLine: "node C proposer = val_0b42 (duplicate)",
    invariant: "I-05",
    check: "node_identity",
  },
  {
    id: "G",
    label: "Malformed justification",
    summary: "Justification payload fails structural parsing.",
    baselineLine: "malformed_justification = false (4/4)",
    mutationLine: "node B malformed_justification = true",
    invariant: "I-06",
    check: "observation_integrity",
  },
  {
    id: "H",
    label: "Canonical mismatch",
    summary: "Canonical evidence disagrees with the observed parent hash.",
    baselineLine: "canonical_consistent = true (4/4)",
    mutationLine: "node A canonical_consistent = false",
    invariant: "I-03",
    check: "finalized_block_state",
  },
];

const ALT_HASH =
  "0x3e91a7c40b52d8fe17a6039c4d81be27350fa9c6187de4025bb93c1f70e844ab";
export const ALT_HASH_SHORT = "0x3e91...44ab";

function clone(f: Fixture): Fixture {
  return { ...f, observations: f.observations.map((o) => ({ ...o })) };
}

export function applyMutation(caseId: CaseId): Fixture {
  const f = clone(BASELINE);
  const a = f.observations[0]!;
  const b = f.observations[1]!;
  const c = f.observations[2]!;
  const d = f.observations[3]!;
  switch (caseId) {
    case "A":
      c.last_finalized_block_number = 184274;
      c.latest_block_number = 184277;
      break;
    case "B":
      d.block_hash = ALT_HASH;
      break;
    case "C":
      b.full_block_available = false;
      break;
    case "D":
      d.reachable = false;
      d.http_status = null;
      d.latency_ms = null;
      d.probe_integrity = false;
      break;
    case "E":
      a.justification_present = false;
      a.justification_count = 0;
      break;
    case "F":
      c.proposer = "val_0b42";
      c.duplicate_validator = true;
      break;
    case "G":
      b.malformed_justification = true;
      break;
    case "H":
      a.canonical_consistent = false;
      break;
    default:
      break;
  }
  return f;
}

/* --------------------------------------------------------------- derivation */

export interface FailureWitness {
  invariantId: string;
  invariant: string;
  expected: string;
  observed: string;
  source: string;
  field: string;
  impact: string;
  verification: Status;
}

export interface Invariant {
  id: string;
  name: string;
  status: Status;
  severity: Severity;
  detail: string;
  evidence: EvidenceRef[];
  witness?: FailureWitness | undefined;
}

export interface VerificationCheck {
  id: string;
  name: string;
  status: Status;
  severity: Severity;
  message: string;
  source: string;
  evidence: EvidenceRef[];
}

export interface Computation {
  reachable: number;
  total: number;
  heightMatches: number;
  hashMatches: number;
  agreementRatio: number;
  quorumObserved: boolean;
  commonHeight: number | null;
  commonHash: string | null;
  heightAgreement: boolean;
  hashAgreement: boolean;
}

export interface Derived {
  fixture: Fixture;
  computation: Computation;
  invariants: Invariant[];
  checks: VerificationCheck[];
  witness: FailureWitness | null;
  status: Status;
}

function ratio(n: number, d: number) {
  return d === 0 ? 0 : Math.round((n / d) * 100) / 100;
}

export function computeAgreement(f: Fixture): Computation {
  const total = f.observations.length;
  const reachableNodes = f.observations.filter((o) => o.reachable);
  const heights = reachableNodes.map((o) => o.last_finalized_block_number);
  const hashes = reachableNodes.map((o) => o.block_hash);
  const commonHeight = heights.length ? heights[0]! : null;
  const commonHash = hashes.length ? hashes[0]! : null;
  const heightMatches = heights.filter((h) => h === commonHeight).length;
  const hashMatches = hashes.filter((h) => h === commonHash).length;
  const agreeing = reachableNodes.filter(
    (o) =>
      o.last_finalized_block_number === commonHeight &&
      o.block_hash === commonHash,
  ).length;
  return {
    reachable: reachableNodes.length,
    total,
    heightMatches,
    hashMatches,
    agreementRatio: ratio(agreeing, total),
    quorumObserved: agreeing * 3 > total * 2,
    commonHeight,
    commonHash,
    heightAgreement: heightMatches === reachableNodes.length && reachableNodes.length > 0,
    hashAgreement: hashMatches === reachableNodes.length && reachableNodes.length > 0,
  };
}

const worst = (a: Status, b: Status): Status => {
  const rank: Record<Status, number> = { PASS: 0, UNAVAILABLE: 1, WARN: 2, FAIL: 3 };
  return rank[a] >= rank[b] ? a : b;
};

function heightEvidence(f: Fixture): EvidenceRef[] {
  return f.observations.map((o) => ({
    source: "RNodeObservation",
    field: `${o.node_id}.last_finalized_block_number`,
    value: o.reachable ? String(o.last_finalized_block_number) : "UNAVAILABLE",
  }));
}

export function evaluateInvariants(f: Fixture, c: Computation): Invariant[] {
  const inv: Invariant[] = [];
  const reachable = f.observations.filter((o) => o.reachable);

  // I-01 finalized height consistency
  const heightOutlier = reachable.find(
    (o) => o.last_finalized_block_number !== c.commonHeight,
  );
  inv.push({
    id: "I-01",
    name: "Finalized height consistency",
    status: heightOutlier ? "FAIL" : "PASS",
    severity: "CRITICAL",
    detail: `${c.heightMatches} / ${c.reachable} reachable observations report the same finalized height.`,
    evidence: heightEvidence(f),
    witness: heightOutlier
      ? {
          invariantId: "I-01",
          invariant: "Finalized height consistency",
          expected: String(c.commonHeight),
          observed: String(heightOutlier.last_finalized_block_number),
          source: heightOutlier.node_id,
          field: "last_finalized_block_number",
          impact: "Cross-node height agreement = false",
          verification: "FAIL",
        }
      : undefined,
  });

  // I-02 block hash consistency
  const hashOutlier = reachable.find((o) => o.block_hash !== c.commonHash);
  inv.push({
    id: "I-02",
    name: "Block hash consistency",
    status: hashOutlier ? "FAIL" : "PASS",
    severity: "CRITICAL",
    detail: `${c.hashMatches} / ${c.reachable} reachable observations report the same block hash.`,
    evidence: f.observations.map((o) => ({
      source: "FinalizedBlockEvidence",
      field: `${o.node_id}.block_hash`,
      value: o.reachable ? o.block_hash : "UNAVAILABLE",
    })),
    witness: hashOutlier
      ? {
          invariantId: "I-02",
          invariant: "Block hash consistency",
          expected: c.commonHash ?? "UNAVAILABLE",
          observed: hashOutlier.block_hash,
          source: hashOutlier.node_id,
          field: "block_hash",
          impact: "Cross-node hash agreement = false",
          verification: "FAIL",
        }
      : undefined,
  });

  // I-03 canonical evidence consistency
  const canonOutlier = reachable.find(
    (o) => !o.canonical_consistent || !o.full_block_available,
  );
  inv.push({
    id: "I-03",
    name: "Canonical evidence consistency",
    status: canonOutlier ? "FAIL" : "PASS",
    severity: "CRITICAL",
    detail:
      "Full block payload retrievable and canonical evidence consistent with the observed parent hash.",
    evidence: f.observations.flatMap((o) => [
      {
        source: "FinalizedBlockEvidence",
        field: `${o.node_id}.full_block_available`,
        value: String(o.full_block_available),
      },
      {
        source: "FinalizedBlockEvidence",
        field: `${o.node_id}.canonical_consistent`,
        value: String(o.canonical_consistent),
      },
    ]),
    witness: canonOutlier
      ? {
          invariantId: "I-03",
          invariant: "Canonical evidence consistency",
          expected: "true",
          observed: "false",
          source: canonOutlier.node_id,
          field: canonOutlier.full_block_available
            ? "canonical_consistent"
            : "full_block_available",
          impact: "Canonical block evidence unavailable for comparison",
          verification: "FAIL",
        }
      : undefined,
  });

  // I-04 observation integrity
  const unreachable = f.observations.filter((o) => !o.reachable);
  inv.push({
    id: "I-04",
    name: "Observation integrity",
    status: unreachable.length ? "WARN" : "PASS",
    severity: "WARNING",
    detail: `${c.reachable} / ${c.total} nodes reachable with intact probe integrity.`,
    evidence: f.observations.map((o) => ({
      source: "RNodeObservation",
      field: `${o.node_id}.reachable`,
      value: String(o.reachable),
    })),
    witness: unreachable.length
      ? {
          invariantId: "I-04",
          invariant: "Observation integrity",
          expected: "reachable = true",
          observed: "reachable = false",
          source: unreachable[0]!.node_id,
          field: "reachable",
          impact: "Observation set reduced; evidence basis narrowed",
          verification: "WARN",
        }
      : undefined,
  });

  // I-05 node identity consistency
  const proposers = f.observations.map((o) => o.proposer);
  const dup = f.observations.find(
    (o, i) => proposers.indexOf(o.proposer) !== i || o.duplicate_validator,
  );
  const networkMismatch = f.observations.find(
    (o) => o.network_id !== f.network || o.shard_id !== f.shard,
  );
  inv.push({
    id: "I-05",
    name: "Node identity consistency",
    status: dup || networkMismatch ? "FAIL" : "PASS",
    severity: "CRITICAL",
    detail: "Distinct proposer identities on a single network and shard.",
    evidence: f.observations.map((o) => ({
      source: "NetworkStatus",
      field: `${o.node_id}.proposer`,
      value: `${o.proposer} @ ${o.network_id}/${o.shard_id}`,
    })),
    witness: dup
      ? {
          invariantId: "I-05",
          invariant: "Node identity consistency",
          expected: "distinct proposer identity per observation",
          observed: `duplicate proposer ${dup.proposer}`,
          source: dup.node_id,
          field: "proposer",
          impact: "Observed stake may be double-counted",
          verification: "FAIL",
        }
      : undefined,
  });

  // I-06 evidence provenance present
  const provOutlier = reachable.find(
    (o) => !o.justification_present || o.malformed_justification || !o.signature_present,
  );
  inv.push({
    id: "I-06",
    name: "Evidence provenance present",
    status: provOutlier ? "FAIL" : "PASS",
    severity: "WARNING",
    detail:
      "Each observation carries a signature and a structurally parseable justification set.",
    evidence: f.observations.flatMap((o) => [
      {
        source: "CasperEvidenceReport",
        field: `${o.node_id}.justification_present`,
        value: String(o.justification_present),
      },
      {
        source: "CasperEvidenceReport",
        field: `${o.node_id}.justification_count`,
        value: String(o.justification_count),
      },
    ]),
    witness: provOutlier
      ? {
          invariantId: "I-06",
          invariant: "Evidence provenance present",
          expected: "justification present and well-formed",
          observed: provOutlier.malformed_justification
            ? "justification malformed"
            : "justification absent",
          source: provOutlier.node_id,
          field: provOutlier.malformed_justification
            ? "malformed_justification"
            : "justification_present",
          impact: "Provenance chain incomplete for this observation",
          verification: "FAIL",
        }
      : undefined,
  });

  // I-07 synthetic classification
  inv.push({
    id: "I-07",
    name: "Synthetic fixture correctly classified",
    status: "PASS",
    severity: "INFO",
    detail:
      "Every displayed value originates from the labelled synthetic fixture; no live source is substituted.",
    evidence: [
      { source: "Fixture", field: "classification", value: "SYNTHETIC" },
      { source: "Fixture", field: "live_endpoint", value: "none" },
    ],
  });

  return inv;
}

export function evaluateChecks(f: Fixture, c: Computation): VerificationCheck[] {
  const obs = f.observations;
  const unreachable = obs.filter((o) => !o.reachable);
  const slow = obs.filter((o) => (o.latency_ms ?? 0) > 250);
  const probeBroken = obs.filter((o) => o.reachable && !o.probe_integrity);
  const proposers = obs.map((o) => o.proposer);
  const dupProposer = obs.some(
    (o, i) => proposers.indexOf(o.proposer) !== i || o.duplicate_validator,
  );
  const notReady = obs.filter((o) => o.reachable && !o.ready);
  const notBonded = obs.filter((o) => o.reachable && o.validator_state !== "bonded");
  const epochs = new Set(obs.filter((o) => o.reachable).map((o) => o.current_epoch));
  const provBroken = obs.filter(
    (o) => o.reachable && (!o.justification_present || o.malformed_justification),
  );
  const blockEvidenceBroken = obs.filter(
    (o) => o.reachable && (!o.full_block_available || !o.canonical_consistent),
  );

  const rows: VerificationCheck[] = [
    {
      id: "reachability",
      name: "Reachability",
      status: unreachable.length ? "WARN" : "PASS",
      severity: "WARNING",
      message: `${c.reachable} / ${c.total} nodes reachable in the observation window.`,
      source: "RNodeObservation",
      evidence: obs.map((o) => ({
        source: "RNodeObservation",
        field: `${o.node_id}.reachable`,
        value: String(o.reachable),
      })),
    },
    {
      id: "http_status",
      name: "HTTP status",
      status: unreachable.length ? "UNAVAILABLE" : "PASS",
      severity: "INFO",
      message: unreachable.length
        ? `HTTP status unavailable for ${unreachable.length} node(s); no substitute value used.`
        : "All probes returned 200.",
      source: "RNodeObservation",
      evidence: obs.map((o) => ({
        source: "RNodeObservation",
        field: `${o.node_id}.http_status`,
        value: o.http_status === null ? "UNAVAILABLE" : String(o.http_status),
      })),
    },
    {
      id: "latency",
      name: "Latency",
      status: slow.length ? "WARN" : "PASS",
      severity: "INFO",
      message: "Observed round-trip latency within the synthetic threshold (250 ms).",
      source: "RNodeObservation",
      evidence: obs.map((o) => ({
        source: "RNodeObservation",
        field: `${o.node_id}.latency_ms`,
        value: o.latency_ms === null ? "UNAVAILABLE" : `${o.latency_ms} ms`,
      })),
    },
    {
      id: "probe_integrity",
      name: "Probe integrity",
      status: probeBroken.length ? "FAIL" : unreachable.length ? "WARN" : "PASS",
      severity: "WARNING",
      message: unreachable.length
        ? "Probe set incomplete; integrity asserted only over responding nodes."
        : "Probe payloads matched their expected shape.",
      source: "RNodeObservation",
      evidence: obs.map((o) => ({
        source: "RNodeObservation",
        field: `${o.node_id}.probe_integrity`,
        value: String(o.probe_integrity),
      })),
    },
    {
      id: "finalized_block_cross_check",
      name: "Finalized block cross-check",
      status: c.heightAgreement ? "PASS" : "FAIL",
      severity: "CRITICAL",
      message: `${c.heightMatches} / ${c.reachable} reachable nodes agree on finalized height; agreement ratio ${c.agreementRatio.toFixed(2)}. Cross-node agreement only — not Casper finality.`,
      source: "CrossNodeReport",
      evidence: [
        {
          source: "CrossNodeReport",
          field: "common_finalized_height",
          value: c.commonHeight === null ? "UNAVAILABLE" : String(c.commonHeight),
        },
        {
          source: "CrossNodeReport",
          field: "agreement_ratio",
          value: c.agreementRatio.toFixed(2),
        },
        ...heightEvidence(f),
      ],
    },
    {
      id: "node_identity",
      name: "Node identity",
      status: dupProposer ? "FAIL" : "PASS",
      severity: "CRITICAL",
      message: dupProposer
        ? "Duplicate proposer identity observed across the node set."
        : "Each observation reports a distinct proposer identity.",
      source: "NetworkStatus",
      evidence: obs.map((o) => ({
        source: "NetworkStatus",
        field: `${o.node_id}.proposer`,
        value: o.proposer,
      })),
    },
    {
      id: "network_identity",
      name: "Network identity",
      status: "PASS",
      severity: "INFO",
      message: `All observations report network ${f.network}, shard ${f.shard}.`,
      source: "NetworkStatus",
      evidence: obs.map((o) => ({
        source: "NetworkStatus",
        field: `${o.node_id}.network_id`,
        value: `${o.network_id}/${o.shard_id}`,
      })),
    },
    {
      id: "readiness",
      name: "Readiness",
      status: notReady.length ? "WARN" : unreachable.length ? "UNAVAILABLE" : "PASS",
      severity: "WARNING",
      message: unreachable.length
        ? "Readiness unavailable for unreachable node(s)."
        : "All responding nodes report ready.",
      source: "NetworkStatus",
      evidence: obs.map((o) => ({
        source: "NetworkStatus",
        field: `${o.node_id}.ready`,
        value: o.reachable ? String(o.ready) : "UNAVAILABLE",
      })),
    },
    {
      id: "validator_state",
      name: "Validator state",
      status: notBonded.length ? "WARN" : "PASS",
      severity: "WARNING",
      message: "Observed validator state and bond count are internally consistent.",
      source: "CasperEvidenceReport",
      evidence: obs.map((o) => ({
        source: "CasperEvidenceReport",
        field: `${o.node_id}.validator_state`,
        value: o.reachable
          ? `${o.validator_state} (bonds ${o.bond_count}, stake ${o.observed_stake})`
          : "UNAVAILABLE",
      })),
    },
    {
      id: "finalized_block_state",
      name: "Finalized block state",
      status: blockEvidenceBroken.length || !c.hashAgreement ? "FAIL" : "PASS",
      severity: "CRITICAL",
      message:
        blockEvidenceBroken.length || !c.hashAgreement
          ? "Block-level evidence inconsistent or unavailable across observations."
          : "Block hash, parent hash and payload digest consistent across observations.",
      source: "FinalizedBlockEvidence",
      evidence: obs.flatMap((o) => [
        {
          source: "FinalizedBlockEvidence",
          field: `${o.node_id}.block_hash`,
          value: o.reachable ? o.block_hash : "UNAVAILABLE",
        },
        {
          source: "FinalizedBlockEvidence",
          field: `${o.node_id}.payload_sha256`,
          value: o.reachable ? o.payload_sha256 : "UNAVAILABLE",
        },
      ]),
    },
    {
      id: "peer_state",
      name: "Peer state",
      status: unreachable.length ? "WARN" : "PASS",
      severity: "INFO",
      message: "Observed peer counts consistent with the synthetic four-node set.",
      source: "NetworkStatus",
      evidence: obs.map((o) => ({
        source: "NetworkStatus",
        field: `${o.node_id}.peer_count`,
        value: o.reachable ? String(o.peer_count) : "UNAVAILABLE",
      })),
    },
    {
      id: "epoch_state",
      name: "Epoch state",
      status: epochs.size > 1 ? "WARN" : "PASS",
      severity: "INFO",
      message: `Observed epoch: ${[...epochs].join(", ") || "UNAVAILABLE"}.`,
      source: "NetworkStatus",
      evidence: obs.map((o) => ({
        source: "NetworkStatus",
        field: `${o.node_id}.current_epoch`,
        value: o.reachable ? String(o.current_epoch) : "UNAVAILABLE",
      })),
    },
    {
      id: "observation_integrity",
      name: "Observation integrity",
      status: provBroken.length ? "FAIL" : "PASS",
      severity: "WARNING",
      message: provBroken.length
        ? "Justification evidence missing or malformed in at least one observation."
        : "Signature and justification evidence present in every observation.",
      source: "VerificationEvidence",
      evidence: obs.flatMap((o) => [
        {
          source: "VerificationEvidence",
          field: `${o.node_id}.signature_present`,
          value: String(o.signature_present),
        },
        {
          source: "VerificationEvidence",
          field: `${o.node_id}.justification_count`,
          value: String(o.justification_count),
        },
      ]),
    },
  ];

  return rows;
}

export function derive(caseId: CaseId): Derived {
  const fixture = caseId === "BASELINE" ? BASELINE : applyMutation(caseId);
  const computation = computeAgreement(fixture);
  const invariants = evaluateInvariants(fixture, computation);
  const checks = evaluateChecks(fixture, computation);
  const witness =
    invariants.find((i) => i.status === "FAIL" && i.witness)?.witness ??
    invariants.find((i) => i.status === "WARN" && i.witness)?.witness ??
    null;
  const status = [...invariants, ...checks].reduce<Status>(
    (acc, r) => worst(acc, r.status === "UNAVAILABLE" ? "PASS" : r.status),
    "PASS",
  );
  return { fixture, computation, invariants, checks, witness, status };
}

/* ------------------------------------------------------------- provenance */

export type ProvenanceKind = "source" | "derived" | "observed" | "verification";

export interface ProvenanceNode {
  id: string;
  type: string;
  identifier: string;
  kind: ProvenanceKind;
  timestamp: string;
  provenance: string;
  fields: EvidenceRef[];
}

export function provenanceChain(d: Derived): ProvenanceNode[] {
  const f = d.fixture;
  const height = d.computation.commonHeight ?? f.block_height;
  return [
    {
      id: "event",
      type: "Event",
      identifier: "evt_7A91",
      kind: "source",
      timestamp: "2026-04-11T09:14:02Z",
      provenance: "origin — synthetic ingress",
      fields: [
        { source: "Event", field: "event_id", value: "evt_7A91" },
        { source: "Event", field: "kind", value: "state_assertion" },
      ],
    },
    {
      id: "process",
      type: "Rholang Process",
      identifier: "rho_proc_0184",
      kind: "derived",
      timestamp: "2026-04-11T09:14:03Z",
      provenance: "derived from evt_7A91",
      fields: [
        { source: "RholangProcess", field: "deploy_hash", value: "0x7f4a...b310" },
        { source: "RholangProcess", field: "source_digest", value: "sha256:41c7...9de2" },
      ],
    },
    {
      id: "trace",
      type: "Execution Trace",
      identifier: `trace_${height}`,
      kind: "derived",
      timestamp: "2026-04-11T09:14:05Z",
      provenance: "derived from rho_proc_0184",
      fields: [
        { source: "ExecutionTrace", field: "trace_hash", value: "0x9c02...ef47" },
        { source: "ExecutionTrace", field: "reductions", value: "1,284" },
      ],
    },
    {
      id: "block",
      type: "RChain Deploy / Block",
      identifier: `block_${height}`,
      kind: "derived",
      timestamp: "2026-04-11T09:14:11Z",
      provenance: "deploy_7f4a included at height " + height,
      fields: [
        { source: "FinalizedBlockEvidence", field: "block_height", value: String(height) },
        {
          source: "FinalizedBlockEvidence",
          field: "block_hash",
          value: d.computation.commonHash ?? "UNAVAILABLE",
        },
      ],
    },
    {
      id: "observation",
      type: "Sentinel Observation",
      identifier: "obs_node_A",
      kind: "observed",
      timestamp: "2026-04-11T09:14:19Z",
      provenance: `observed by ${d.computation.reachable} / ${d.computation.total} nodes`,
      fields: [
        {
          source: "RNodeObservation",
          field: "reachable_nodes",
          value: `${d.computation.reachable} / ${d.computation.total}`,
        },
        {
          source: "RNodeObservation",
          field: "last_finalized_block_number",
          value: String(height),
        },
      ],
    },
    {
      id: "evidence",
      type: "Evidence Graph",
      identifier: `evidence_${height}`,
      kind: "observed",
      timestamp: "2026-04-11T09:14:21Z",
      provenance: "corroborated across observations",
      fields: [
        {
          source: "CrossNodeReport",
          field: "agreement_ratio",
          value: d.computation.agreementRatio.toFixed(2),
        },
        {
          source: "CrossNodeReport",
          field: "conflicting_nodes",
          value: String(d.computation.total - Math.round(d.computation.agreementRatio * d.computation.total)),
        },
      ],
    },
    {
      id: "verification",
      type: "Independent Verification",
      identifier: `verify_${height}`,
      kind: "verification",
      timestamp: "2026-04-11T09:14:22Z",
      provenance: "verification result tied to the evidence above",
      fields: [
        { source: "VerificationReport", field: "status", value: d.status },
        {
          source: "VerificationReport",
          field: "evidence_basis",
          value: `${d.checks.reduce((n, c) => n + c.evidence.length, 0)} evidence records`,
        },
      ],
    },
  ];
}

export interface EvidenceEdge {
  id: string;
  from: string;
  to: string;
  relation: "observes" | "corroborates" | "compares" | "supports" | "produces";
  detail: EvidenceRef;
}

export const EVIDENCE_NODES = [
  "RNodeObservation",
  "FinalizedBlockEvidence",
  "CrossNodeReport",
  "VerificationCheck",
  "VerificationReport",
] as const;

export function evidenceEdges(d: Derived): EvidenceEdge[] {
  const height = d.computation.commonHeight;
  return [
    {
      id: "e1",
      from: "RNodeObservation",
      to: "FinalizedBlockEvidence",
      relation: "observes",
      detail: {
        source: "RNodeObservation",
        field: "last_finalized_block_number",
        value: height === null ? "UNAVAILABLE" : String(height),
      },
    },
    {
      id: "e2",
      from: "FinalizedBlockEvidence",
      to: "CrossNodeReport",
      relation: "corroborates",
      detail: {
        source: "FinalizedBlockEvidence",
        field: "block_hash",
        value: d.computation.commonHash ?? "UNAVAILABLE",
      },
    },
    {
      id: "e3",
      from: "CrossNodeReport",
      to: "VerificationCheck",
      relation: "compares",
      detail: {
        source: "CrossNodeReport",
        field: "agreement_ratio",
        value: d.computation.agreementRatio.toFixed(2),
      },
    },
    {
      id: "e4",
      from: "VerificationCheck",
      to: "VerificationReport",
      relation: "supports",
      detail: {
        source: "VerificationCheck",
        field: "finalized_block_cross_check.status",
        value:
          d.checks.find((c) => c.id === "finalized_block_cross_check")?.status ??
          "UNAVAILABLE",
      },
    },
    {
      id: "e5",
      from: "VerificationReport",
      to: "VerificationReport",
      relation: "produces",
      detail: {
        source: "VerificationReport",
        field: "status",
        value: d.status,
      },
    },
  ];
}

/* ------------------------------------------------------------- divergence */

export interface DivergenceRow {
  field: string;
  baseline: string;
  active: string;
  diverged: boolean;
}

export function divergence(active: Derived) {
  const base = derive("BASELINE");
  const rows: DivergenceRow[] = [
    {
      field: "RNodeObservation.reachable_nodes",
      baseline: `${base.computation.reachable} / ${base.computation.total}`,
      active: `${active.computation.reachable} / ${active.computation.total}`,
      diverged: base.computation.reachable !== active.computation.reachable,
    },
    {
      field: "CrossNodeReport.common_finalized_height",
      baseline: String(base.computation.commonHeight),
      active: String(active.computation.commonHeight),
      diverged: base.computation.commonHeight !== active.computation.commonHeight,
    },
    {
      field: "CrossNodeReport.height_agreement",
      baseline: String(base.computation.heightAgreement),
      active: String(active.computation.heightAgreement),
      diverged: base.computation.heightAgreement !== active.computation.heightAgreement,
    },
    {
      field: "CrossNodeReport.hash_agreement",
      baseline: String(base.computation.hashAgreement),
      active: String(active.computation.hashAgreement),
      diverged: base.computation.hashAgreement !== active.computation.hashAgreement,
    },
    {
      field: "CrossNodeReport.agreement_ratio",
      baseline: base.computation.agreementRatio.toFixed(2),
      active: active.computation.agreementRatio.toFixed(2),
      diverged: base.computation.agreementRatio !== active.computation.agreementRatio,
    },
    ...base.invariants.map((bi, i) => ({
      field: `Invariant.${bi.id}`,
      baseline: bi.status,
      active: active.invariants[i]!.status,
      diverged: bi.status !== active.invariants[i]!.status,
    })),
    {
      field: "VerificationReport.status",
      baseline: base.status,
      active: active.status,
      diverged: base.status !== active.status,
    },
  ];
  const first = rows.find((r) => r.diverged) ?? null;
  const affectedInvariant =
    active.invariants.find((i) => i.status !== "PASS")?.id ?? null;
  const affectedCheck =
    active.checks.find((c) => c.status === "FAIL" || c.status === "WARN")?.id ?? null;
  return { baseline: base, rows, first, affectedInvariant, affectedCheck };
}
