import { cn } from "@/lib/utils";
import { useWorkbench, type StageId } from "@/lib/workbench-state";
import type { Status } from "@/lib/fixture";
import { StatusDot } from "./primitives";

const STAGES: { id: StageId; label: string }[] = [
  { id: "claim", label: "Claim" },
  { id: "inputs", label: "Inputs" },
  { id: "computation", label: "Computation" },
  { id: "invariants", label: "Invariants" },
  { id: "adversarial", label: "Adversarial Tests" },
  { id: "evidence", label: "Evidence" },
  { id: "result", label: "Result" },
];

export function PipelineSpine() {
  const { stage, setStage, derived, isBaseline } = useWorkbench();

  const statusFor = (id: StageId): Status => {
    switch (id) {
      case "invariants":
        return derived.invariants.some((i) => i.status === "FAIL")
          ? "FAIL"
          : derived.invariants.some((i) => i.status === "WARN")
            ? "WARN"
            : "PASS";
      case "adversarial":
        return isBaseline ? "PASS" : "FAIL";
      case "result":
        return derived.status;
      case "computation":
        return derived.computation.heightAgreement && derived.computation.hashAgreement
          ? "PASS"
          : "FAIL";
      default:
        return "PASS";
    }
  };

  return (
    <div className="flex flex-col gap-1 lg:flex-row lg:items-stretch">
      {STAGES.map((s, i) => {
        const active = stage === s.id;
        return (
          <div key={s.id} className="flex items-center gap-1 lg:flex-1">
            <button
              type="button"
              onClick={() => setStage(s.id)}
              className={cn(
                "group flex w-full items-center justify-between gap-2 border px-2 py-1.5 text-left transition-all duration-150",
                active
                  ? "border-primary/70 bg-primary/10"
                  : "border-border bg-panel/70 hover:border-border-strong hover:bg-elevated/60",
              )}
            >
              <span className="min-w-0">
                <span className="block font-mono text-[9.5px] tracking-widest text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span
                  className={cn(
                    "block truncate text-[11.5px]",
                    active ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  {s.label}
                </span>
              </span>
              <StatusDot status={statusFor(s.id)} />
            </button>
            {i < STAGES.length - 1 ? (
              <svg
                className="hidden h-4 w-4 shrink-0 lg:block"
                viewBox="0 0 16 16"
                aria-hidden
              >
                <line
                  x1="0"
                  y1="8"
                  x2="16"
                  y2="8"
                  className="flow-line"
                  stroke="var(--border-strong)"
                  strokeWidth="1"
                />
              </svg>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
