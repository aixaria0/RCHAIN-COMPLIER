import { cn } from "@/lib/utils";
import { CASES, type CaseId } from "@/lib/fixture";
import { useWorkbench } from "@/lib/workbench-state";
import {
  EvidenceList,
  Expandable,
  FieldRow,
  Hint,
  Mono,
  Panel,
  SeverityTag,
  StatusTag,
  SyntheticTag,
  Unavailable,
} from "./primitives";

/* -------------------------------------------------------------- inputs */

export function InputsPanel() {
  const { derived } = useWorkbench();
  const f = derived.fixture;

  return (
    <Panel
      title="Evidence Inputs"
      subtitle="Protocol-shaped evidence objects from the synthetic fixture. Each field carries its evidence source."
      right={<SyntheticTag />}
    >
      <div className="grid gap-3 xl:grid-cols-2">
        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1 font-mono text-[10px] tracking-widest text-primary">
            NetworkStatus
          </h3>
          <FieldRow
            label="network id"
            value={f.network}
            source="NetworkStatus"
            field="network_id"
          />
          <FieldRow label="shard id" value={f.shard} source="NetworkStatus" field="shard_id" />
          <FieldRow
            label="target"
            value={f.target}
            source="NetworkStatus"
            field="node_identity"
          />
          <FieldRow
            label="current epoch"
            value={String(f.observations[0]!.current_epoch)}
            source="NetworkStatus"
            field="current_epoch"
          />
        </div>

        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1 font-mono text-[10px] tracking-widest text-primary">
            FinalizedBlockEvidence
          </h3>
          <FieldRow
            label="finalized block"
            value={String(derived.computation.commonHeight ?? "")}
            source="RNodeObservation"
            field="last_finalized_block_number"
            unavailable={derived.computation.commonHeight === null}
          />
          <FieldRow
            label="latest block"
            value={String(f.observations[0]!.latest_block_number)}
            source="RNodeObservation"
            field="latest_block_number"
          />
          <FieldRow
            label="block hash"
            value={derived.computation.commonHash ?? ""}
            source="FinalizedBlockEvidence"
            field="block_hash"
            unavailable={derived.computation.commonHash === null}
          />
          <FieldRow
            label="parent hash"
            value={f.observations[0]!.parent_hash}
            source="FinalizedBlockEvidence"
            field="parent_hash"
          />
          <FieldRow
            label="payload sha-256"
            value={f.observations[0]!.payload_sha256}
            source="FinalizedBlockEvidence"
            field="payload_sha256"
          />
          <FieldRow
            label="full block available"
            value={f.observations.every((o) => o.full_block_available) ? "true" : "partial"}
            source="FinalizedBlockEvidence"
            field="full_block_available"
          />
          <FieldRow
            label="canonical consistency"
            value={f.observations.every((o) => o.canonical_consistent) ? "true" : "false"}
            source="FinalizedBlockEvidence"
            field="canonical_consistent"
          />
        </div>

        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1 font-mono text-[10px] tracking-widest text-primary">
            CrossNodeReport
          </h3>
          <FieldRow
            label="cross-node agreement"
            value={String(derived.computation.heightAgreement && derived.computation.hashAgreement)}
            source="CrossNodeReport"
            field="agreement"
          />
          <FieldRow
            label="agreement ratio"
            value={derived.computation.agreementRatio.toFixed(2)}
            source="CrossNodeReport"
            field="agreement_ratio"
          />
          <FieldRow
            label="conflicting nodes"
            value={String(
              f.observations.filter(
                (o) =>
                  o.reachable &&
                  (o.last_finalized_block_number !== derived.computation.commonHeight ||
                    o.block_hash !== derived.computation.commonHash),
              ).length,
            )}
            source="CrossNodeReport"
            field="conflicting_nodes"
          />
          <FieldRow
            label="reachable nodes"
            value={`${derived.computation.reachable} / ${derived.computation.total}`}
            source="CrossNodeReport"
            field="reachable_nodes"
          />
        </div>

        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1 font-mono text-[10px] tracking-widest text-primary">
            CasperEvidenceReport
          </h3>
          <p className="mb-1 text-[10.5px] text-muted-foreground">
            <Hint text="Observed, protocol-shaped evidence about validator and justification state. Not a finality determination.">
              Protocol-shaped evidence only
            </Hint>
          </p>
          <FieldRow
            label="validator state"
            value={f.observations[0]!.validator_state}
            source="CasperEvidenceReport"
            field="validator_state"
          />
          <FieldRow
            label="signature presence"
            value={String(f.observations.every((o) => o.signature_present))}
            source="CasperEvidenceReport"
            field="signature_present"
          />
          <FieldRow
            label="justification presence"
            value={String(f.observations.every((o) => o.justification_present))}
            source="CasperEvidenceReport"
            field="justification_present"
          />
          <FieldRow
            label="justification count"
            value={f.observations.map((o) => o.justification_count).join(" / ")}
            source="CasperEvidenceReport"
            field="justification_count"
          />
          <FieldRow
            label="observed stake"
            value={f.observations
              .filter((o) => o.reachable)
              .reduce((n, o) => n + o.observed_stake, 0)
              .toLocaleString("en-US")}
            source="CasperEvidenceReport"
            field="observed_stake"
          />
          <FieldRow
            label="bond count"
            value={String(f.observations[0]!.bond_count)}
            source="CasperEvidenceReport"
            field="bond_count"
          />
        </div>
      </div>

      <h3 className="mt-3 mb-1 font-mono text-[10px] tracking-widest text-primary">
        RNodeObservation · per node
      </h3>
      <div className="overflow-x-auto border border-border/70">
        <table className="w-full border-collapse text-left font-mono text-[10.5px]">
          <thead className="bg-muted/30 text-muted-foreground">
            <tr>
              {[
                "node",
                "reachable",
                "http",
                "latency",
                "ready",
                "validator",
                "finalized",
                "block_hash",
                "proposer",
                "justif.",
              ].map((h) => (
                <th key={h} className="px-2 py-1 font-normal tracking-widest">
                  {h.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {f.observations.map((o) => {
              const outlier =
                o.last_finalized_block_number !== derived.computation.commonHeight ||
                o.block_hash !== derived.computation.commonHash ||
                !o.reachable;
              return (
                <tr
                  key={o.node_id}
                  className={cn(
                    "border-t border-border/50",
                    outlier && "bg-fail/5 text-fail",
                  )}
                >
                  <td className="px-2 py-1">{o.node_id}</td>
                  <td className="px-2 py-1">{String(o.reachable)}</td>
                  <td className="px-2 py-1">{o.http_status ?? "UNAVAILABLE"}</td>
                  <td className="px-2 py-1">
                    {o.latency_ms === null ? "UNAVAILABLE" : `${o.latency_ms}ms`}
                  </td>
                  <td className="px-2 py-1">{o.reachable ? String(o.ready) : "—"}</td>
                  <td className="px-2 py-1">{o.reachable ? o.validator_state : "—"}</td>
                  <td className="px-2 py-1">{o.last_finalized_block_number}</td>
                  <td className="px-2 py-1">{o.block_hash.slice(0, 8)}…{o.block_hash.slice(-4)}</td>
                  <td className="px-2 py-1">{o.proposer}</td>
                  <td className="px-2 py-1">
                    {o.malformed_justification ? "malformed" : o.justification_count}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-[10.5px] text-muted-foreground">
        Individual fields are observed evidence, not independent proof. A verdict requires
        the corroborating checks below.
      </p>
    </Panel>
  );
}

/* --------------------------------------------------------- computation */

export function ComputationPanel() {
  const { derived } = useWorkbench();
  const c = derived.computation;
  const f = derived.fixture;

  const line = (label: string, value: string, ok: boolean) => (
    <div className="flex items-center justify-between gap-3 border-b border-border/50 py-1 last:border-b-0">
      <span className="font-mono text-[11px] text-muted-foreground">{label}</span>
      <span
        className={cn("font-mono text-[11px]", ok ? "text-pass" : "text-fail")}
      >
        {value}
      </span>
    </div>
  );

  return (
    <Panel
      title="Verification Computation"
      subtitle="Deterministic comparisons over the fixture. No sampling, no randomness."
      right={<SyntheticTag />}
    >
      <div className="grid gap-3 lg:grid-cols-2">
        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1.5 font-mono text-[10px] tracking-widest text-primary">
            HEIGHT COMPARISON
          </h3>
          <div className="mb-2 font-mono text-[10.5px] text-muted-foreground">
            RNode finalized height <span className="text-accent">vs</span> independent
            block evidence height
          </div>
          {f.observations.map((o) => (
            <div
              key={o.node_id}
              className="flex items-center justify-between border-b border-border/40 py-1 font-mono text-[10.5px] last:border-b-0"
            >
              <span className="text-muted-foreground">{o.node_id}</span>
              <span
                className={cn(
                  !o.reachable
                    ? "text-muted-foreground"
                    : o.last_finalized_block_number === c.commonHeight
                      ? "text-foreground"
                      : "text-fail",
                )}
              >
                {o.reachable ? o.last_finalized_block_number : "UNAVAILABLE"}
              </span>
            </div>
          ))}
        </div>

        <div className="border border-border/70 bg-background/40 p-2">
          <h3 className="mb-1.5 font-mono text-[10px] tracking-widest text-primary">
            HASH COMPARISON
          </h3>
          {f.observations.map((o) => (
            <div
              key={o.node_id}
              className="flex items-center justify-between gap-2 border-b border-border/40 py-1 font-mono text-[10.5px] last:border-b-0"
            >
              <span className="text-muted-foreground">{o.node_id}</span>
              <span
                className={cn(
                  "break-all",
                  !o.reachable
                    ? "text-muted-foreground"
                    : o.block_hash === c.commonHash
                      ? "text-foreground"
                      : "text-fail",
                )}
              >
                {o.reachable
                  ? `${o.block_hash.slice(0, 10)}…${o.block_hash.slice(-4)}`
                  : "UNAVAILABLE"}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-3 border border-border/70 bg-background/40 p-2">
        <h3 className="mb-1.5 font-mono text-[10px] tracking-widest text-primary">
          DERIVED VALUES
        </h3>
        {line(
          "reachable nodes",
          `${c.reachable} / ${c.total}`,
          c.reachable === c.total,
        )}
        {line(
          "matching finalized height",
          `${c.heightMatches} / ${c.reachable}`,
          c.heightAgreement,
        )}
        {line("matching block hash", `${c.hashMatches} / ${c.reachable}`, c.hashAgreement)}
        {line("agreement ratio", c.agreementRatio.toFixed(2), c.agreementRatio === 1)}
        {line("quorum observed", String(c.quorumObserved), c.quorumObserved)}
      </div>
      <p className="mt-2 text-[10.5px] text-muted-foreground">
        <Hint text="Agreement across observed nodes is an evidence signal. It is not a Casper finality determination, and Sovereign-Lattice PBFT is a separate protocol.">
          Cross-node agreement
        </Hint>{" "}
        only — never read as Casper finality.
      </p>
    </Panel>
  );
}

/* ---------------------------------------------------------- invariants */

export function InvariantsPanel() {
  const { derived } = useWorkbench();
  return (
    <Panel
      title="Invariant Checks"
      subtitle="Frontend consistency checks over the fixture. These are not Lean proofs."
      right={<SyntheticTag />}
    >
      <div>
        {derived.invariants.map((inv) => (
          <Expandable
            key={inv.id}
            header={
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="font-mono text-[11px] text-accent">{inv.id}</span>
                <span className="text-[12px]">{inv.name}</span>
                <StatusTag status={inv.status} />
                <SeverityTag severity={inv.severity} />
              </div>
            }
          >
            <p className="mb-1.5 text-[11px] text-muted-foreground">{inv.detail}</p>
            <EvidenceList evidence={inv.evidence} />
          </Expandable>
        ))}
      </div>
    </Panel>
  );
}

/* --------------------------------------------------------------- matrix */

export function VerificationMatrix() {
  const { derived } = useWorkbench();
  return (
    <Panel
      title="Verification Matrix"
      subtitle="Checks conceptually mirroring the Sentinel verification engine. Expand a row for its evidence basis."
      right={<SyntheticTag />}
    >
      <div className="grid grid-cols-[minmax(0,12rem)_4.5rem_5.5rem_minmax(0,1fr)_3.5rem_minmax(0,9rem)] gap-x-2 border-b border-border/70 bg-muted/30 px-2 py-1 font-mono text-[10px] tracking-widest text-muted-foreground">
        <span>CHECK</span>
        <span>STATUS</span>
        <span>SEVERITY</span>
        <span>MESSAGE</span>
        <span>EVID.</span>
        <span>SOURCE</span>
      </div>
      {derived.checks.map((c) => (
        <Expandable
          key={c.id}
          header={
            <div className="grid grid-cols-[minmax(0,12rem)_4.5rem_5.5rem_minmax(0,1fr)_3.5rem_minmax(0,9rem)] items-center gap-x-2 pr-2">
              <span className="truncate text-[11.5px]">{c.name}</span>
              <StatusTag status={c.status} />
              <SeverityTag severity={c.severity} />
              <span className="truncate text-[11px] text-muted-foreground">
                {c.message}
              </span>
              <Mono className="text-muted-foreground">{c.evidence.length}</Mono>
              <Mono className="truncate text-accent">{c.source}</Mono>
            </div>
          }
        >
          <p className="mb-1.5 text-[11px] text-muted-foreground">{c.message}</p>
          <EvidenceList evidence={c.evidence} />
        </Expandable>
      ))}
    </Panel>
  );
}

/* ------------------------------------------------------ failure witness */

export function FailureWitnessPanel() {
  const { derived, isBaseline } = useWorkbench();
  const w = derived.witness;

  if (!w) {
    return (
      <Panel title="Failure Witness" subtitle="Synthetic diagnostic witness">
        <p className="text-[12px] text-pass">
          No failure witness — all selected invariants satisfied.
        </p>
        {isBaseline ? (
          <p className="mt-1 text-[10.5px] text-muted-foreground">
            Activate an adversarial case to generate a witness.
          </p>
        ) : null}
      </Panel>
    );
  }

  return (
    <Panel
      title="Failure Witness"
      subtitle="Synthetic diagnostic witness generated by the prototype — not a formal counterexample."
      right={<StatusTag status={w.verification} />}
      className="border-fail/40"
    >
      <div className="grid gap-x-6 md:grid-cols-2">
        <FieldRow label="Invariant" value={`${w.invariantId} · ${w.invariant}`} />
        <FieldRow label="Expected" value={w.expected} />
        <FieldRow label="Observed" value={w.observed} />
        <FieldRow label="Source" value={w.source} />
        <FieldRow label="Field" value={w.field} />
        <FieldRow label="Impact" value={w.impact} />
        <FieldRow label="Verification" value={w.verification} />
      </div>
    </Panel>
  );
}

/* --------------------------------------------------- adversarial controls */

export function AdversarialControls({ compact = false }: { compact?: boolean }) {
  const { activeCase, setActiveCase, isBaseline } = useWorkbench();

  const cell = (id: CaseId, label: string, sub?: string) => (
    <button
      key={id}
      type="button"
      onClick={() => setActiveCase(id)}
      className={cn(
        "border px-2 py-1.5 text-left transition-all duration-150",
        activeCase === id
          ? "border-warn/60 bg-warn/10"
          : "border-border bg-panel/70 hover:border-border-strong hover:bg-elevated/60",
      )}
    >
      <div className="flex items-center gap-2">
        <span className="font-mono text-[10px] tracking-widest text-accent">
          {id === "BASELINE" ? "BASE" : id}
        </span>
        <span className="text-[11.5px]">{label}</span>
      </div>
      {sub && !compact ? (
        <p className="mt-0.5 text-[10.5px] text-muted-foreground">{sub}</p>
      ) : null}
    </button>
  );

  return (
    <Panel
      title="Adversarial Cases"
      subtitle="Deterministic mutations of the synthetic baseline. Selecting a case re-derives the entire workbench."
      right={
        <span className="font-mono text-[10px] tracking-widest text-muted-foreground">
          {isBaseline ? "BASELINE ACTIVE" : `CASE ${activeCase} ACTIVE`}
        </span>
      }
    >
      <div className={cn("grid gap-1.5", compact ? "sm:grid-cols-3" : "sm:grid-cols-2 xl:grid-cols-3")}>
        {cell("BASELINE", "Baseline fixture", "Unmutated synthetic evidence set.")}
        {CASES.map((c) => cell(c.id, c.label, c.summary))}
      </div>
    </Panel>
  );
}

export function MutationDetail() {
  const { activeCase, derived, isBaseline } = useWorkbench();
  const c = CASES.find((x) => x.id === activeCase);

  if (isBaseline || !c) {
    return (
      <Panel title="Mutation Propagation" subtitle="No mutation applied">
        <Unavailable reason="Baseline fixture active — there is no mutation to propagate." />
      </Panel>
    );
  }

  const inv = derived.invariants.find((i) => i.id === c.invariant);
  const chk = derived.checks.find((k) => k.id === c.check);

  return (
    <Panel
      title="Mutation Propagation"
      subtitle={`Case ${c.id} · ${c.label}`}
      right={<StatusTag status={derived.status} />}
    >
      <div className="grid gap-2 md:grid-cols-2">
        <div className="border border-border/70 bg-background/40 p-2">
          <div className="font-mono text-[10px] tracking-widest text-muted-foreground">
            BASELINE
          </div>
          <Mono className="text-foreground">{c.baselineLine}</Mono>
        </div>
        <div className="border border-warn/40 bg-warn/5 p-2">
          <div className="font-mono text-[10px] tracking-widest text-warn">MUTATION</div>
          <Mono className="text-warn">{c.mutationLine}</Mono>
        </div>
      </div>

      <ol className="mt-3 space-y-1.5">
        {[
          { label: "Detected divergence", value: c.mutationLine },
          { label: "Affected invariant", value: inv ? `${inv.id} · ${inv.name} → ${inv.status}` : "—" },
          { label: "Affected verification check", value: chk ? `${chk.id} → ${chk.status}` : "—" },
          {
            label: "Affected evidence",
            value: derived.witness
              ? `${derived.witness.source} · ${derived.witness.field}`
              : "—",
          },
          { label: "Resulting verification status", value: derived.status },
        ].map(({ label, value }, i) => (
          <li key={label} className="flex items-start gap-2">
            <span className="mt-0.5 font-mono text-[10px] text-accent">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="h-px w-4 shrink-0 translate-y-2 bg-border-strong" />
            <div className="min-w-0">
              <div className="font-mono text-[10px] tracking-widest text-muted-foreground">
                {label.toUpperCase()}
              </div>
              <Mono>{value}</Mono>
            </div>
          </li>
        ))}
      </ol>
    </Panel>
  );
}
