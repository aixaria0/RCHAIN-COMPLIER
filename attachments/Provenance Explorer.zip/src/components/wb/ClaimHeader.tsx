import { useWorkbench } from "@/lib/workbench-state";

import { FieldRow, Hint, Mono, Panel, StatusTag, SyntheticTag } from "./primitives";

export function ClaimHeader() {
  const { derived } = useWorkbench();
  const f = derived.fixture;
  const c = derived.computation;

  return (
    <Panel
      title="Claim"
      subtitle="The assertion under verification"
      right={
        <div className="flex items-center gap-2">
          <SyntheticTag />
          <StatusTag status={derived.status} />
        </div>
      }
    >
      <h1 className="text-[15px] leading-snug font-medium text-foreground">{f.claim}</h1>
      <div className="mt-2 grid gap-x-6 md:grid-cols-2 xl:grid-cols-3">
        <FieldRow label="Target" value={f.target} source="NetworkStatus" field="node_identity" />
        <FieldRow
          label="Block height"
          value={String(c.commonHeight ?? "")}
          source="RNodeObservation"
          field="last_finalized_block_number"
          unavailable={c.commonHeight === null}
        />
        <FieldRow
          label="Block hash"
          value={c.commonHash ? `${c.commonHash.slice(0, 6)}...${c.commonHash.slice(-4)}` : ""}
          source="FinalizedBlockEvidence"
          field="block_hash"
          unavailable={c.commonHash === null}
        />
        <FieldRow label="Network" value={f.network} source="NetworkStatus" field="network_id" />
        <FieldRow
          label="Verification status"
          value={derived.status}
          source="VerificationReport"
          field="status"
        />
        <FieldRow
          label="Evidence basis"
          value={`${derived.checks.reduce((n, k) => n + k.evidence.length, 0)} evidence records across ${derived.checks.length} checks`}
          source="VerificationReport"
          field="evidence_basis"
        />
      </div>
      <p className="mt-2 border border-border/70 bg-background/50 px-2 py-1.5 text-[11px] text-muted-foreground">
        <Mono className="text-accent">{derived.status}</Mono> means the synthetic
        consistency checks listed below{" "}
        {derived.status === "PASS" ? "passed" : "did not all pass"}. It is{" "}
        <Hint text="Casper finality is a consensus property of RChain and cannot be established from Sentinel observations. Sovereign-Lattice PBFT is a separate protocol and is never treated as Casper.">
          not a claim of Casper finality
        </Hint>
        , and not a proof.
      </p>
    </Panel>
  );
}
