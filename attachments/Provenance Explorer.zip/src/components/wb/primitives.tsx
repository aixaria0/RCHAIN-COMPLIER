import { useState, type ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { EvidenceRef, Severity, Status } from "@/lib/fixture";

export function StatusDot({ status, className }: { status: Status; className?: string }) {
  const tone =
    status === "PASS"
      ? "bg-pass"
      : status === "WARN"
        ? "bg-warn"
        : status === "FAIL"
          ? "bg-fail"
          : "bg-muted-foreground";
  return (
    <span
      className={cn("inline-block size-1.5 shrink-0 rounded-full", tone, className)}
      aria-hidden
    />
  );
}

export function StatusTag({ status }: { status: Status }) {
  const tone =
    status === "PASS"
      ? "text-pass border-pass/40 bg-pass/10"
      : status === "WARN"
        ? "text-warn border-warn/40 bg-warn/10"
        : status === "FAIL"
          ? "text-fail border-fail/40 bg-fail/10"
          : "text-muted-foreground border-border bg-muted/40";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 border px-1.5 py-0.5 font-mono text-[10px] tracking-widest",
        tone,
      )}
    >
      <StatusDot status={status} />
      {status}
    </span>
  );
}

export function SeverityTag({ severity }: { severity: Severity }) {
  const tone =
    severity === "CRITICAL"
      ? "text-fail"
      : severity === "WARNING"
        ? "text-warn"
        : "text-muted-foreground";
  return (
    <span className={cn("font-mono text-[10px] tracking-widest", tone)}>{severity}</span>
  );
}

export function Panel({
  title,
  subtitle,
  right,
  children,
  className,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={cn(
        "border border-border bg-card/70 backdrop-blur-[1px]",
        className,
      )}
    >
      <header className="flex items-start justify-between gap-3 border-b border-border px-3 py-2">
        <div>
          <h2 className="font-mono text-[11px] tracking-[0.18em] text-foreground uppercase">
            {title}
          </h2>
          {subtitle ? (
            <p className="mt-0.5 text-[11px] leading-tight text-muted-foreground">
              {subtitle}
            </p>
          ) : null}
        </div>
        {right}
      </header>
      <div className="p-3">{children}</div>
    </section>
  );
}

export function Mono({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("font-mono text-[11px] break-all text-foreground", className)}>
      {children}
    </span>
  );
}

export function FieldRow({
  label,
  value,
  source,
  field,
  unavailable,
}: {
  label: string;
  value: string;
  source?: string;
  field?: string;
  unavailable?: boolean;
}) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5 border-b border-border/60 py-1.5 last:border-b-0">
      <div className="min-w-40">
        <div className="text-[11px] text-muted-foreground">{label}</div>
        {source ? (
          <div className="font-mono text-[10px] text-accent/80">
            {source}
            {field ? ` · ${field}` : ""}
          </div>
        ) : null}
      </div>
      <span
        className={cn(
          "font-mono text-[11px] break-all",
          unavailable ? "text-muted-foreground" : "text-foreground",
        )}
      >
        {unavailable ? "UNAVAILABLE" : value}
      </span>
    </div>
  );
}

export function EvidenceList({ evidence }: { evidence: EvidenceRef[] }) {
  return (
    <div className="border border-border/70 bg-background/60">
      <div className="grid grid-cols-[minmax(0,10rem)_minmax(0,1fr)_minmax(0,1fr)] border-b border-border/70 bg-muted/30 px-2 py-1 font-mono text-[10px] tracking-widest text-muted-foreground">
        <span>SOURCE</span>
        <span>FIELD</span>
        <span>VALUE</span>
      </div>
      <div className="max-h-64 overflow-auto">
        {evidence.map((e, i) => (
          <div
            key={`${e.field}-${i}`}
            className="grid grid-cols-[minmax(0,10rem)_minmax(0,1fr)_minmax(0,1fr)] gap-x-2 border-b border-border/40 px-2 py-1 font-mono text-[10.5px] last:border-b-0"
          >
            <span className="text-accent">{e.source}</span>
            <span className="text-muted-foreground break-all">{e.field}</span>
            <span
              className={cn(
                "break-all",
                e.value === "UNAVAILABLE" ? "text-muted-foreground" : "text-foreground",
              )}
            >
              {e.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Expandable({
  header,
  children,
  defaultOpen = false,
}: {
  header: ReactNode;
  children: ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-border/60 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 py-1.5 text-left transition-colors hover:bg-elevated/40"
      >
        <ChevronRight
          className={cn(
            "size-3 shrink-0 text-muted-foreground transition-transform",
            open && "rotate-90",
          )}
        />
        <div className="min-w-0 flex-1">{header}</div>
      </button>
      {open ? <div className="pb-2 pl-5">{children}</div> : null}
    </div>
  );
}

export function Hint({ text, children }: { text: string; children: ReactNode }) {
  return (
    <span
      title={text}
      className="cursor-help border-b border-dotted border-muted-foreground/60"
    >
      {children}
    </span>
  );
}

export function SyntheticTag({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-block border border-accent/40 bg-accent/10 px-1.5 py-0.5 font-mono text-[9.5px] tracking-widest text-accent",
        className,
      )}
    >
      SYNTHETIC
    </span>
  );
}

export function Unavailable({ reason }: { reason: string }) {
  return (
    <div className="border border-border/70 bg-background/60 px-2 py-1.5">
      <span className="font-mono text-[10px] tracking-widest text-muted-foreground">
        UNAVAILABLE
      </span>
      <p className="mt-0.5 text-[11px] text-muted-foreground">{reason}</p>
    </div>
  );
}
