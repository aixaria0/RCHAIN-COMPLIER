import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  EVIDENCE_NODES,
  evidenceEdges,
  provenanceChain,
  type ProvenanceKind,
} from "@/lib/fixture";
import { useWorkbench } from "@/lib/workbench-state";
import { EvidenceList, FieldRow, Mono, Panel, StatusTag, SyntheticTag } from "./primitives";

const KIND_STYLE: Record<ProvenanceKind, { label: string; cls: string }> = {
  source: { label: "SOURCE EVENT", cls: "border-primary/60 bg-primary/10 text-primary" },
  derived: { label: "DERIVED ARTIFACT", cls: "border-border-strong bg-panel text-foreground" },
  observed: { label: "OBSERVED EVIDENCE", cls: "border-accent/60 bg-accent/10 text-accent" },
  verification: {
    label: "VERIFICATION RESULT",
    cls: "border-pass/50 bg-pass/10 text-pass",
  },
};

export function CausalityGraph() {
  const { derived, selectedNode, setSelectedNode } = useWorkbench();
  const nodes = provenanceChain(derived);
  const selected = nodes.find((n) => n.id === selectedNode) ?? nodes[0]!;

  return (
    <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <Panel
        title="Causality Explorer"
        subtitle="Event → Rholang Process → Execution Trace → RChain Deploy / Block → Sentinel Observation → Evidence Graph → Independent Verification"
        right={<SyntheticTag />}
      >
        <div className="flex flex-col gap-0">
          {nodes.map((n, i) => {
            const style = KIND_STYLE[n.kind];
            const active = selected.id === n.id;
            return (
              <div key={n.id}>
                <button
                  type="button"
                  onClick={() => setSelectedNode(n.id)}
                  className={cn(
                    "flex w-full flex-wrap items-center justify-between gap-x-3 gap-y-1 border px-2.5 py-2 text-left transition-all duration-150",
                    style.cls,
                    active
                      ? "ring-1 ring-ring/70"
                      : "opacity-80 hover:opacity-100",
                  )}
                >
                  <div className="min-w-0">
                    <div className="font-mono text-[9.5px] tracking-widest opacity-70">
                      {style.label}
                    </div>
                    <div className="text-[12.5px] text-foreground">{n.type}</div>
                  </div>
                  <div className="text-right">
                    <Mono className="block">{n.identifier}</Mono>
                    <span className="font-mono text-[10px] text-muted-foreground">
                      {n.timestamp}
                    </span>
                  </div>
                </button>
                {i < nodes.length - 1 ? (
                  <svg className="h-6 w-full" viewBox="0 0 100 24" preserveAspectRatio="none" aria-hidden>
                    <line
                      x1="6"
                      y1="0"
                      x2="6"
                      y2="24"
                      className="flow-line"
                      stroke="var(--border-strong)"
                      strokeWidth="0.6"
                      vectorEffect="non-scaling-stroke"
                    />
                  </svg>
                ) : null}
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[10.5px] text-muted-foreground">
          Provenance is preserved across each transformation. Not every transformation is
          cryptographically proven — links marked as derived are structural references.
        </p>
      </Panel>

      <Panel
        title="Provenance Detail"
        subtitle={`${selected.type} · ${selected.identifier}`}
        right={<StatusTag status={derived.status} />}
      >
        <FieldRow label="type" value={selected.type} />
        <FieldRow label="identifier" value={selected.identifier} />
        <FieldRow label="classification" value={KIND_STYLE[selected.kind].label} />
        <FieldRow label="timestamp" value={selected.timestamp} />
        <FieldRow label="provenance reference" value={selected.provenance} />
        <div className="mt-2">
          <EvidenceList evidence={selected.fields} />
        </div>
      </Panel>
    </div>
  );
}

export function EvidenceRelationGraph() {
  const { derived } = useWorkbench();
  const edges = evidenceEdges(derived);
  const [selected, setSelected] = useState(edges[0]!.id);
  const edge = edges.find((e) => e.id === selected) ?? edges[0]!;

  return (
    <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_20rem]">
      <Panel
        title="Evidence Graph"
        subtitle="Evidence relationships behind the verification result. Select an edge to see its source, field and value."
        right={<SyntheticTag />}
      >
        <div className="flex flex-col">
          {EVIDENCE_NODES.map((node, i) => {
            const outgoing = edges.find((e) => e.from === node && e.to !== node);
            return (
              <div key={node}>
                <div className="flex items-center justify-between border border-border bg-panel/70 px-2.5 py-2">
                  <span className="text-[12.5px]">{node}</span>
                  <Mono className="text-muted-foreground">
                    {i === EVIDENCE_NODES.length - 1 ? derived.status : "evidence node"}
                  </Mono>
                </div>
                {outgoing ? (
                  <button
                    type="button"
                    onClick={() => setSelected(outgoing.id)}
                    className={cn(
                      "flex w-full items-center gap-2 px-2 py-1 text-left transition-colors",
                      selected === outgoing.id ? "bg-accent/10" : "hover:bg-elevated/50",
                    )}
                  >
                    <svg className="h-5 w-3 shrink-0" viewBox="0 0 12 20" aria-hidden>
                      <line
                        x1="6"
                        y1="0"
                        x2="6"
                        y2="20"
                        className="flow-line"
                        stroke={selected === outgoing.id ? "var(--accent)" : "var(--border-strong)"}
                        strokeWidth="1"
                      />
                    </svg>
                    <span
                      className={cn(
                        "font-mono text-[10px] tracking-widest",
                        selected === outgoing.id ? "text-accent" : "text-muted-foreground",
                      )}
                    >
                      {outgoing.relation.toUpperCase()}
                    </span>
                  </button>
                ) : null}
              </div>
            );
          })}
        </div>
        <p className="mt-2 text-[10.5px] text-muted-foreground">
          The final verification result is always traceable back to observed evidence.
        </p>
      </Panel>

      <Panel title="Edge Detail" subtitle={`${edge.from} → ${edge.to}`}>
        <FieldRow label="relation" value={edge.relation} />
        <FieldRow label="source" value={edge.detail.source} />
        <FieldRow label="field" value={edge.detail.field} />
        <FieldRow label="value" value={edge.detail.value} />
        <div className="mt-2 flex flex-wrap gap-1">
          {["Observed", "Derived", "Compared", "Verified"].map((t) => (
            <span
              key={t}
              className="border border-border px-1.5 py-0.5 font-mono text-[9.5px] tracking-widest text-muted-foreground"
            >
              {t.toUpperCase()}
            </span>
          ))}
        </div>
      </Panel>
    </div>
  );
}
