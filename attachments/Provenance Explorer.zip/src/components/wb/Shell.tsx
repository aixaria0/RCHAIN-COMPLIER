import { Link, useNavigate } from "@tanstack/react-router";
import {
  Activity,
  Boxes,
  FlaskConical,
  GitCompareArrows,
  Network,
  ShieldAlert,
  Workflow,
  RotateCcw,
  Play,
  Search,
  SplitSquareHorizontal,
} from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useWorkbench } from "@/lib/workbench-state";
import { CASES } from "@/lib/fixture";
import { StatusTag } from "./primitives";

const NAV = [
  { to: "/", label: "Verification Workbench", icon: Activity },
  { to: "/claim-lab", label: "Claim Lab", icon: FlaskConical },
  { to: "/adversarial", label: "Adversarial Cases", icon: ShieldAlert },
  { to: "/causality", label: "Causality Explorer", icon: Workflow },
  { to: "/evidence-graph", label: "Evidence Graph", icon: Network },
  { to: "/replay", label: "Replay / Divergence", icon: GitCompareArrows },
  { to: "/architecture", label: "Architecture", icon: Boxes },
] as const;

function SyntheticBanner() {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-accent/30 bg-accent/10 px-4 py-1.5">
      <span className="font-mono text-[10px] tracking-[0.22em] text-accent">
        SYNTHETIC FIXTURE
      </span>
      <span className="font-mono text-[10px] tracking-[0.22em] text-accent/80">
        UI / ARCHITECTURE DEMONSTRATION
      </span>
      <span className="font-mono text-[10px] tracking-[0.22em] text-accent/80">
        NOT LIVE RCHAIN EVIDENCE
      </span>
      <span className="ml-auto inline-flex items-center gap-1.5 font-mono text-[10px] tracking-widest text-primary">
        <span className="size-1.5 rounded-full bg-primary pulse-node" />
        EVIDENCE-FIRST VERIFICATION
      </span>
    </div>
  );
}

function ControlBar() {
  const { activeCase, reset, runNextAdversarial, isBaseline, derived } = useWorkbench();
  const navigate = useNavigate();
  const activeLabel =
    CASES.find((c) => c.id === activeCase)?.label ?? "Baseline fixture";

  const btn =
    "inline-flex items-center gap-1.5 border border-border bg-panel px-2.5 py-1 font-mono text-[10px] tracking-widest text-foreground transition-colors hover:border-border-strong hover:bg-elevated";

  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-border bg-card/60 px-4 py-2">
      <div className="mr-2 flex items-center gap-2">
        <span className="font-mono text-[10px] tracking-widest text-muted-foreground">
          FIXTURE STATE
        </span>
        <span
          className={cn(
            "font-mono text-[11px]",
            isBaseline ? "text-foreground" : "text-warn",
          )}
        >
          {isBaseline ? "BASELINE" : `CASE ${activeCase} · ${activeLabel}`}
        </span>
        <StatusTag status={derived.status} />
      </div>
      <div className="ml-auto flex flex-wrap items-center gap-2">
        <button type="button" className={btn} onClick={reset}>
          <RotateCcw className="size-3" /> RESET TO BASELINE
        </button>
        <button type="button" className={btn} onClick={runNextAdversarial}>
          <Play className="size-3" /> RUN ADVERSARIAL TEST
        </button>
        <button
          type="button"
          className={btn}
          onClick={() => navigate({ to: "/evidence-graph" })}
        >
          <Search className="size-3" /> TRACE EVIDENCE
        </button>
        <button
          type="button"
          className={btn}
          onClick={() => navigate({ to: "/replay" })}
        >
          <SplitSquareHorizontal className="size-3" /> REPLAY DIVERGENCE
        </button>
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <SyntheticBanner />
      <div className="flex min-h-[calc(100vh-2rem)]">
        <aside className="hidden w-56 shrink-0 border-r border-border bg-card/40 md:block">
          <div className="border-b border-border px-4 py-3">
            <div className="font-mono text-[10px] tracking-[0.2em] text-primary">
              RCHAIN
            </div>
            <div className="text-sm leading-tight font-semibold">Reality Compiler</div>
            <div className="mt-0.5 font-mono text-[10px] tracking-widest text-muted-foreground">
              VERIFICATION WORKBENCH
            </div>
          </div>
          <nav className="p-2">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                className="group flex items-center gap-2 border-l-2 border-transparent px-2 py-1.5 text-[12px] text-muted-foreground transition-colors hover:bg-elevated/50 hover:text-foreground data-[status=active]:border-l-primary data-[status=active]:bg-elevated/60 data-[status=active]:text-foreground"
              >
                <item.icon className="size-3.5 shrink-0" />
                <span className="truncate">{item.label}</span>
              </Link>
            ))}
          </nav>
          <div className="mx-2 mt-2 border border-border/70 bg-background/50 p-2">
            <p className="text-[10.5px] leading-snug text-muted-foreground">
              Verification results describe observed evidence and cross-node agreement.
              They are not claims of Casper finality.
            </p>
          </div>
        </aside>
        <main className="min-w-0 flex-1">
          <ControlBar />
          <div className="grid-backdrop min-h-full p-4">{children}</div>
        </main>
      </div>
    </div>
  );
}

export function MobileNav() {
  return (
    <nav className="mb-3 flex gap-1 overflow-x-auto border border-border bg-card/60 p-1 md:hidden">
      {NAV.map((item) => (
        <Link
          key={item.to}
          to={item.to}
          activeOptions={{ exact: item.to === "/" }}
          className="shrink-0 px-2 py-1 font-mono text-[10px] tracking-widest text-muted-foreground data-[status=active]:bg-elevated data-[status=active]:text-foreground"
        >
          {item.label.toUpperCase()}
        </Link>
      ))}
    </nav>
  );
}
