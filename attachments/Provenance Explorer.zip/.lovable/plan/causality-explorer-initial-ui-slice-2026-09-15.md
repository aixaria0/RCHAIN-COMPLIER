# Causality Explorer — Initial UI Slice

## Goal
Plan the smallest read-only provenance view for the future RChain Reality Compiler, to be implemented after the `rchain-sentinel` repository is connected.

The view will present one synthetic chain:

```text
Event
  → Rholang Process
  → Execution Trace
  → RChain Block
  → Sentinel Evidence
  → Verification Result
```

## Scope
- Add one Causality Explorer view within the existing Sentinel application shell and navigation pattern.
- Render six ordered stages as a clear provenance spine, responsive from a vertical mobile flow to the existing desktop layout conventions.
- Show only compact evidence at each stage:
  - **Event:** event ID
  - **Rholang Process:** source or deploy hash
  - **Execution Trace:** trace hash
  - **RChain Block:** block height and block hash
  - **Sentinel Evidence:** observed node count/list and evidence status
  - **Verification Result:** PASS or FAIL and a short verification basis
- Display a prominent, persistent **SYNTHETIC / DEMO DATA** label near the view title and provenance data.
- Keep the fixture deterministic and local to the UI; no loading, persistence, or remote requests.

## Minimal UI Architecture
- **Route/view:** one route using the repository’s established TanStack route and page-shell conventions.
- **Provenance component:** one focused component that maps the six fixture stages into the visual spine.
- **Fixture/type:** a small typed static object or array colocated with the view unless the connected repository already has an established fixtures location.
- **Stage presentation:** reuse Sentinel’s existing card/panel, badge/status, icon, typography, spacing, and color tokens. Use CSS connectors/arrows rather than a graph library.
- **Evidence treatment:** short labels and truncated hashes with full values available through the project’s existing detail/tooltip pattern, if one exists.

## Implementation Sequence
1. Once `rchain-sentinel` is connected, inspect `docs/REALITY_COMPILER.md`, the application shell, route/navigation conventions, and the smallest relevant set of design-system components.
2. Confirm the exact route placement and reuse existing components without altering Sentinel APIs.
3. Add the typed synthetic fixture and the six-stage Causality Explorer spine.
4. Add only the minimum navigation entry needed if the existing application requires one to reach the view.
5. Verify the view at mobile and desktop sizes, including stage order, connector continuity, readable evidence, hash overflow, and the demo-data label.
6. Check the existing project build/runtime diagnostics and stop when this slice works.

## Technical Constraints
- No new dependencies.
- No database, persistence, external connector, or API changes.
- No real RChain, QuantumOS, QLF, or Sovereign-Lattice integration.
- No changes to existing Sentinel API contracts.
- No unrelated refactoring, redesign, or cleanup.
- Do not modify this blank Lovable starter; implementation begins only after the actual repository is connected.

## Acceptance Criteria
- The six stages appear in the required order and read as one connected provenance chain.
- Every stage displays its requested compact evidence.
- The final stage clearly shows PASS or FAIL and its verification basis.
- Synthetic content is unmistakably labeled **SYNTHETIC / DEMO DATA**.
- The view fits the existing Sentinel visual language and remains usable on mobile and desktop.
- No network request, persistence layer, dependency, or existing API modification is introduced.
