# RChain Reality Compiler — Verification Workbench

A read-only, deterministic prototype: one synthetic fixture, seven views, one shared state model. No live chain, no backend, no auth.

Note: this project currently contains only the blank starter (a placeholder home page). The Rust backend and existing Sentinel UI are not present here, so the prototype is built fresh in the frontend, following the pipeline and terminology rules exactly as specified.

## Visual direction
Deep near-black background, restrained deep-blue surfaces, amber for evidence/provenance, cyan/blue technical accents, thin borders, compact type, monospaced hashes and identifiers, subtle connection animations. Desktop/tablet first. No gradients, illustrations, or stock imagery.

## Shell
- Left navigation rail: Verification Workbench, Claim Lab, Adversarial Cases, Causality Explorer, Evidence Graph, Replay / Divergence, Architecture.
- Persistent top banner: SYNTHETIC FIXTURE — UI / ARCHITECTURE DEMONSTRATION — NOT LIVE RCHAIN EVIDENCE, plus an "Evidence-first verification" indicator.
- Global controls: RESET TO BASELINE, RUN ADVERSARIAL TEST, TRACE EVIDENCE, REPLAY DIVERGENCE.

## Views
1. **Verification Workbench** (default, at `/`): claim card ("Observed finalized block is consistent across the available evidence paths."), target `synthetic-rchain-node`, height 184273, hash `0x7f4a...91c2`, network `synthetic-testnet`, status PASS with explicit note that PASS means synthetic checks passed, not Casper finality. Clickable stage spine Claim → Inputs → Computation → Invariants → Adversarial Tests → Evidence → Result, updating a detail panel in place. Includes Evidence Inputs panel (NetworkStatus, RNodeObservation, FinalizedBlockEvidence, CrossNodeReport, CasperEvidenceReport, VerificationReport, VerificationCheck, VerificationEvidence) with per-field source/field/value attribution, the Verification Computation panel (4/4 reachable, height and hash agreement, ratio 1.00, quorum observed), and the dense Verification Matrix (Check, Status, Severity, Message, Evidence Count, Source) with expandable evidence rows.
2. **Claim Lab**: the claim, its decomposition into invariants and checks, and its evidence basis.
3. **Adversarial Cases**: eight deterministic mutations (A–H) applied to the baseline fixture, showing divergence → invariant → check → evidence → resulting status, plus the Failure Witness panel (expected/observed/source/field/impact/verification) or "No failure witness — all selected invariants satisfied."
4. **Causality Explorer**: interactive provenance graph Event → Rholang Process → Execution Trace → RChain Deploy / Block → Sentinel Observation → Evidence Graph → Independent Verification, using the given synthetic IDs; nodes show type, identifier, status, timestamp, provenance reference and open a detail panel. Visual classes distinguish source event, derived artifact, observed evidence, verification result.
5. **Evidence Graph**: RNodeObservation → FinalizedBlockEvidence → CrossNodeReport → VerificationCheck → VerificationReport, edges labelled observes / corroborates / compares / supports / produces; clicking an edge shows source, field, value.
6. **Replay / Divergence**: split-screen baseline vs adversarial pipeline, first divergence point, affected invariant and check, final result.
7. **Architecture**: RChain/RNode → Evidence Adapter → EvidenceEnvelope → Sentinel Observation → Verification Engine → Evidence Graph → Reality Compiler → Causality Explorer, with Rholang Execution Adapter and Sovereign-Lattice Verification Adapter marked as adapter boundary / planned integration.

Invariants I-01 through I-07 render with PASS/WARN/FAIL, severity INFO/WARNING/CRITICAL, and an expandable evidence trail, explicitly not described as Lean proofs.

## Technical notes
- One typed fixture module: baseline objects mirroring the Sentinel data model, plus a pure `applyMutation(caseId)` producing the mutated fixture and a pure derivation that computes cross-node agreement, invariants, checks, failure witness, and divergence point from whichever fixture is active.
- Single shared state (selected mutation + selected stage/node) in a small React context so every view reflects the same mutation; no per-widget local demo data.
- Routes under `src/routes/`, one file per view, each with its own head metadata; nav rail in a layout. Design tokens (near-black, deep blue, amber, cyan, status colors) added to `src/styles.css`; no hardcoded color utilities.
- Graphs drawn with SVG/CSS connectors and short CSS transitions; no new dependencies.
- Terminology enforced throughout: verification result, evidence, consistency check, failure witness, observed evidence, cross-node agreement, protocol-shaped evidence. Never "proof", "Casper proven", or "finality proven". Unavailable sources render UNAVAILABLE with a reason.

## Acceptance
Switching an adversarial case updates claim status, invariants, verification matrix, failure witness, both graphs, replay divergence, and final result together; RESET TO BASELINE returns everything to PASS; all synthetic values are visibly labelled.
